<!-- ======= Header ======= -->
<header id="header" class="fixed-top">
    <div class="container d-flex">

      <div class="logo mr-auto">
        <h1 class="text-light"><a href="<?php echo base_url('') ?>"><span>DDART</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="<?php echo base_url('') ?>">Home</a></li>
          <li><a href="<?php echo base_url('#about') ?>">Tentang Kami</a>
          </li>
          <li><a href="<?php echo base_url('#services') ?>">Layanan Kami</a></li>

          <li><a href="<?php echo base_url('#contact') ?>">Contact</a></li>

        </ul>
      </nav>
      <!-- .nav-menu -->

    </div>
  </header>
  <!-- End Header -->