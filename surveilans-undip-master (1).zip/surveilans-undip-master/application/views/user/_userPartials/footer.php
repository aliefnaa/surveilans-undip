  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top" style="padding-top: 0%;">
      <div class="container">
        <div class="copyright">
          Copyright &copy; 2020 <strong><span>DDART</span></strong>. All Rights Reserved
        </div>
      </div>
    </div>
  </footer>
  <!-- End Footer -->