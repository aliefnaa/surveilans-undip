# Web Surveilens D-DART UNDIP
Dibuat oleh Tim KKN TEMATIK Undip 2020

## SCREENSHOT
![Alt text](/screenshot/kkn1.PNG?raw=true "KKN")
![Alt text](/screenshot/kkn2.PNG?raw=true "KKN")
![Alt text](/screenshot/kkn3.PNG?raw=true "KKN")
![Alt text](/screenshot/kkn4.PNG?raw=true "KKN")
![Alt text](/screenshot/kkn5.PNG?raw=true "KKN")
